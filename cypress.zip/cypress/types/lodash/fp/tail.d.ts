import { tail } from "../fp";
export = tail;
