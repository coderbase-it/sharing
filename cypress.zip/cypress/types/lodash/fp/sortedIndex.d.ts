import { sortedIndex } from "../fp";
export = sortedIndex;
