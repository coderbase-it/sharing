import { lte } from "../fp";
export = lte;
