import { invertObj } from "../fp";
export = invertObj;
