import { merge } from "../fp";
export = merge;
