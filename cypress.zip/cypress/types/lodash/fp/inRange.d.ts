import { inRange } from "../fp";
export = inRange;
