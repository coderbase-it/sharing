import { isNull } from "../fp";
export = isNull;
