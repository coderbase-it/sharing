import { dropWhile } from "../fp";
export = dropWhile;
