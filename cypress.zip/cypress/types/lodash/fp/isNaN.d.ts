import { isNaN } from "../fp";
export = isNaN;
