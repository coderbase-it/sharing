import { wrap } from "../fp";
export = wrap;
