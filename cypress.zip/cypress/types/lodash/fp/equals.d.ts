import { equals } from "../fp";
export = equals;
