import { toSafeInteger } from "../fp";
export = toSafeInteger;
