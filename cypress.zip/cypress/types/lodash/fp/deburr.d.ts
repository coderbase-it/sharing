import { deburr } from "../fp";
export = deburr;
