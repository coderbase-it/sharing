import { throttle } from "../fp";
export = throttle;
