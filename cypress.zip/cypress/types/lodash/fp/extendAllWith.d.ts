import { extendAllWith } from "../fp";
export = extendAllWith;
