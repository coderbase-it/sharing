import { each } from "../fp";
export = each;
