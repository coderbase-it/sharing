import { sortedLastIndexBy } from "../fp";
export = sortedLastIndexBy;
