import { overSome } from "../fp";
export = overSome;
