import { isWeakMap } from "../fp";
export = isWeakMap;
