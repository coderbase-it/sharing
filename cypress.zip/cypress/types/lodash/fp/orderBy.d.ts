import { orderBy } from "../fp";
export = orderBy;
