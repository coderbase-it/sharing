import { update } from "../fp";
export = update;
