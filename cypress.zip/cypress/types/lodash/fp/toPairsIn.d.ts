import { toPairsIn } from "../fp";
export = toPairsIn;
