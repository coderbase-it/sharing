import { forEach } from "../fp";
export = forEach;
