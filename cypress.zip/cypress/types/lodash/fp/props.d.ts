import { props } from "../fp";
export = props;
