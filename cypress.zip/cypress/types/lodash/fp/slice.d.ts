import { slice } from "../fp";
export = slice;
