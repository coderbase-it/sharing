import { dropWhile } from "./index";
export = dropWhile;
