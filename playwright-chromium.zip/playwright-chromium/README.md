# playwright-chromium
This package contains the [Chromium](https://www.chromium.org/) flavor of [Playwright](http://github.com/microsoft/playwright).
